#include <iostream>
using namespace std;
int main() {
	char buf[12];
	cin >> buf;
	cout << "echo: " << buf << endl;
}